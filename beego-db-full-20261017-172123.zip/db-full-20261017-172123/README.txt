Beego full database backup
Created: 2026-10-17T17:21:28+07:00
Source host: local MySQL on this VPS

Included databases (full schema + data + routines/triggers/events):
1) beego_vn.sql
   - Production database (latest)
2) beego_call_preview.sql
   - Learn Call preview/test database
3) beego_vn_verify_20261007-222504.sql
   - Historical verify snapshot still on server

Restore (example):
  mysql -u root -p < beego_vn.sql
  mysql -u root -p < beego_call_preview.sql
  mysql -u root -p < beego_vn_verify_20261007-222504.sql

Notes:
- This archive contains personal user data. Keep it private.
- App secrets (.env.local) are NOT included.
beego_call_preview | tables=27 | size_mb=1.13
beego_vn | tables=54 | size_mb=7.22
beego_vn_verify_20261007-222504 | tables=49 | size_mb=5.63
beego_vn.users=8
beego_vn.subscriptions=9
beego_vn.user_sessions=1804
