-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: localhost    Database: beego_call_preview
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.24.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `beego_call_preview`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `beego_call_preview` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `beego_call_preview`;

--
-- Table structure for table `ai_usage_daily`
--

DROP TABLE IF EXISTS `ai_usage_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_usage_daily` (
  `user_id` bigint unsigned NOT NULL,
  `usage_date` date NOT NULL,
  `request_count` int unsigned NOT NULL DEFAULT '0',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`,`usage_date`),
  KEY `idx_usage_date` (`usage_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ai_usage_daily`
--

LOCK TABLES `ai_usage_daily` WRITE;
/*!40000 ALTER TABLE `ai_usage_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `ai_usage_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_settings`
--

DROP TABLE IF EXISTS `app_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_settings` (
  `setting_key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `setting_value` longtext COLLATE utf8mb4_unicode_ci,
  `is_encrypted` tinyint(1) NOT NULL DEFAULT '0',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_settings`
--

LOCK TABLES `app_settings` WRITE;
/*!40000 ALTER TABLE `app_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `learn_placement_answers`
--

DROP TABLE IF EXISTS `learn_placement_answers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learn_placement_answers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `session_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer_key` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lesson_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `skill_key` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `difficulty_level` tinyint unsigned NOT NULL,
  `is_correct` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_lpa_answer_key` (`answer_key`),
  KEY `idx_lpa_session` (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `learn_placement_answers`
--

LOCK TABLES `learn_placement_answers` WRITE;
/*!40000 ALTER TABLE `learn_placement_answers` DISABLE KEYS */;
/*!40000 ALTER TABLE `learn_placement_answers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `learn_placement_sessions`
--

DROP TABLE IF EXISTS `learn_placement_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learn_placement_sessions` (
  `session_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `status` enum('active','completed','abandoned') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `ability_score` decimal(8,3) NOT NULL DEFAULT '0.000',
  `difficulty_level` tinyint unsigned NOT NULL DEFAULT '2',
  `asked_count` int unsigned NOT NULL DEFAULT '0',
  `correct_count` int unsigned NOT NULL DEFAULT '0',
  `current_item_json` json DEFAULT NULL,
  `asked_refs_json` json DEFAULT NULL,
  `skill_stats_json` json DEFAULT NULL,
  `guest_token` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`session_id`),
  KEY `idx_lps_user` (`user_id`),
  KEY `idx_lps_guest` (`guest_token`),
  KEY `idx_lps_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `learn_placement_sessions`
--

LOCK TABLES `learn_placement_sessions` WRITE;
/*!40000 ALTER TABLE `learn_placement_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `learn_placement_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stripe_webhook_events`
--

DROP TABLE IF EXISTS `stripe_webhook_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stripe_webhook_events` (
  `event_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_type` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`event_id`),
  KEY `idx_event_type` (`event_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stripe_webhook_events`
--

LOCK TABLES `stripe_webhook_events` WRITE;
/*!40000 ALTER TABLE `stripe_webhook_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `stripe_webhook_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscriptions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `plan` enum('free','pro','vip') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'free',
  `trial_start_at` datetime NOT NULL,
  `trial_end_at` datetime NOT NULL,
  `subscribed_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `stripe_customer_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripe_subscription_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_purchase_token` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_product_id` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source` enum('stripe','sepay','google_play','manual','trial') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'trial',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_subscriptions_user` (`user_id`),
  UNIQUE KEY `uk_stripe_subscription` (`stripe_subscription_id`),
  KEY `idx_subscriptions_expires` (`expires_at`),
  KEY `idx_subscriptions_google_token` (`google_purchase_token`(191))
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscriptions`
--

LOCK TABLES `subscriptions` WRITE;
/*!40000 ALTER TABLE `subscriptions` DISABLE KEYS */;
INSERT INTO `subscriptions` VALUES (1,1,'pro','0000-00-00 00:00:00','2026-10-08 10:58:25',NULL,'2026-11-08 10:58:25',NULL,NULL,NULL,NULL,'trial','2026-10-09 10:58:25','2026-10-09 11:48:23'),(14,2,'pro','2026-10-09 10:58:25','2026-10-08 10:58:25','2026-10-09 10:58:25','2026-11-08 10:58:25',NULL,NULL,NULL,NULL,'trial','2026-10-09 10:58:25','2026-10-09 11:48:23'),(16,3,'free','2026-10-15 11:01:03','2026-10-30 11:01:03',NULL,NULL,NULL,NULL,NULL,NULL,'trial','2026-10-15 11:01:03','2026-10-15 11:01:03');
/*!40000 ALTER TABLE `subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_events`
--

DROP TABLE IF EXISTS `user_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_events` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `attempt_id` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_type` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `word_id` bigint unsigned DEFAULT NULL,
  `is_correct` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_events_attempt` (`user_id`,`attempt_id`,`event_type`),
  KEY `idx_user_events_user_created` (`user_id`,`created_at`),
  KEY `idx_user_events_user_type_created` (`user_id`,`event_type`,`created_at`),
  KEY `fk_user_events_word` (`word_id`),
  CONSTRAINT `fk_user_events_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_user_events_word` FOREIGN KEY (`word_id`) REFERENCES `vocabulary` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_events`
--

LOCK TABLES `user_events` WRITE;
/*!40000 ALTER TABLE `user_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_learn_achievements`
--

DROP TABLE IF EXISTS `user_learn_achievements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_learn_achievements` (
  `user_id` bigint unsigned NOT NULL,
  `achievement_key` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unlocked_at` datetime NOT NULL,
  `meta_json` json DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`,`achievement_key`),
  KEY `idx_ula_unlocked` (`user_id`,`unlocked_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_learn_achievements`
--

LOCK TABLES `user_learn_achievements` WRITE;
/*!40000 ALTER TABLE `user_learn_achievements` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_learn_achievements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_learn_achievements_cache`
--

DROP TABLE IF EXISTS `user_learn_achievements_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_learn_achievements_cache` (
  `user_id` bigint unsigned NOT NULL,
  `payload_json` json NOT NULL,
  `input_fingerprint` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  KEY `idx_ulac2_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_learn_achievements_cache`
--

LOCK TABLES `user_learn_achievements_cache` WRITE;
/*!40000 ALTER TABLE `user_learn_achievements_cache` DISABLE KEYS */;
INSERT INTO `user_learn_achievements_cache` VALUES (3,'{\"total\": 26, \"cached\": false, \"metrics\": {\"streak\": 0, \"xp_total\": 0, \"honey_total\": 0, \"srs_reviews\": 0, \"skills_strong\": 0, \"perfect_lessons\": 0, \"lessons_completed\": 0, \"mistakes_resolved\": 0, \"placement_completed\": 0, \"daily_goals_completed\": 0}, \"unlocked\": [], \"inProgress\": [], \"generatedAt\": \"2026-10-15T04:05:14.944Z\", \"lockedCount\": 26, \"newlyUnlocked\": [], \"unlockedCount\": 0}','bda34c82e44a4eac6bf7afb97be76c245ff9f7c682edacf4b5709cb6e4631586','2026-10-15 11:06:00','2026-10-15 04:05:14','2026-10-15 04:05:14');
/*!40000 ALTER TABLE `user_learn_achievements_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_learn_analytics_cache`
--

DROP TABLE IF EXISTS `user_learn_analytics_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_learn_analytics_cache` (
  `user_id` bigint unsigned NOT NULL,
  `payload_json` json NOT NULL,
  `input_fingerprint` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  KEY `idx_ulac_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_learn_analytics_cache`
--

LOCK TABLES `user_learn_analytics_cache` WRITE;
/*!40000 ALTER TABLE `user_learn_analytics_cache` DISABLE KEYS */;
INSERT INTO `user_learn_analytics_cache` VALUES (3,'{\"cached\": false, \"insights\": [{\"code\": \"INSUFFICIENT_DATA\", \"text\": \"Chưa đủ dữ liệu học tập — hoàn thành vài bài để xem tiến độ chi tiết.\", \"severity\": \"info\", \"skillKey\": null}], \"analytics\": {\"skills\": [{\"empty\": true, \"label\": \"Từ vựng\", \"wrong\": 0, \"correct\": 0, \"attempts\": 0, \"skillKey\": \"vocabulary\", \"accuracyPct\": 0, \"masteryPhase\": \"NEW\", \"masteryScore\": 0}, {\"empty\": true, \"label\": \"Ngữ pháp\", \"wrong\": 0, \"correct\": 0, \"attempts\": 0, \"skillKey\": \"grammar\", \"accuracyPct\": 0, \"masteryPhase\": \"NEW\", \"masteryScore\": 0}, {\"empty\": true, \"label\": \"Mẫu câu\", \"wrong\": 0, \"correct\": 0, \"attempts\": 0, \"skillKey\": \"sentence_patterns\", \"accuracyPct\": 0, \"masteryPhase\": \"NEW\", \"masteryScore\": 0}, {\"empty\": true, \"label\": \"Listening\", \"wrong\": 0, \"correct\": 0, \"attempts\": 0, \"skillKey\": \"listening\", \"accuracyPct\": 0, \"masteryPhase\": \"NEW\", \"masteryScore\": 0}, {\"empty\": true, \"label\": \"Speaking\", \"wrong\": 0, \"correct\": 0, \"attempts\": 0, \"skillKey\": \"speaking\", \"accuracyPct\": 0, \"masteryPhase\": \"NEW\", \"masteryScore\": 0}, {\"empty\": true, \"label\": \"Đọc hiểu\", \"wrong\": 0, \"correct\": 0, \"attempts\": 0, \"skillKey\": \"comprehension\", \"accuracyPct\": 0, \"masteryPhase\": \"NEW\", \"masteryScore\": 0}], \"overview\": {\"trend\": \"insufficient_data\", \"srsDue\": 0, \"streak\": 0, \"xpToday\": 0, \"xpTotal\": 0, \"dataSparse\": true, \"honeyTotal\": 0, \"trendDelta\": null, \"activeDays7\": 0, \"dailyGoalXp\": 30, \"lessonsTotal\": 128, \"openMistakes\": 0, \"pathProgressPct\": 0, \"lessonsCompleted\": 0, \"reviewsRecovered\": 0, \"dailyGoalCompleted\": false, \"overallAccuracyPct\": null, \"dailyGoalProgressPct\": 0}, \"placement\": null, \"strengths\": [], \"activity7d\": [{\"xp\": 0, \"date\": \"2026-10-09\", \"active\": false, \"lessons\": 0, \"attempts\": 0}, {\"xp\": 0, \"date\": \"2026-10-10\", \"active\": false, \"lessons\": 0, \"attempts\": 0}, {\"xp\": 0, \"date\": \"2026-10-11\", \"active\": false, \"lessons\": 0, \"attempts\": 0}, {\"xp\": 0, \"date\": \"2026-10-12\", \"active\": false, \"lessons\": 0, \"attempts\": 0}, {\"xp\": 0, \"date\": \"2026-10-13\", \"active\": false, \"lessons\": 0, \"attempts\": 0}, {\"xp\": 0, \"date\": \"2026-10-14\", \"active\": false, \"lessons\": 0, \"attempts\": 0}, {\"xp\": 0, \"date\": \"2026-10-15\", \"active\": false, \"lessons\": 0, \"attempts\": 0}], \"weaknesses\": [], \"generatedAt\": \"2026-10-15T04:05:14.752Z\"}, \"recommendationsHref\": \"/?focus=today\"}','9a74f701166b6bbe6e9f0e11017922d87c7404dcf33ecc2adbb74098721ca57d','2026-10-15 11:06:15','2026-10-15 04:01:43','2026-10-15 04:05:14');
/*!40000 ALTER TABLE `user_learn_analytics_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_learn_daily_progress`
--

DROP TABLE IF EXISTS `user_learn_daily_progress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_learn_daily_progress` (
  `user_id` bigint unsigned NOT NULL,
  `progress_date` date NOT NULL,
  `goal_xp` int unsigned NOT NULL DEFAULT '30',
  `xp_earned` int unsigned NOT NULL DEFAULT '0',
  `lessons_completed` int unsigned NOT NULL DEFAULT '0',
  `goal_completed_at` datetime DEFAULT NULL,
  `streak_applied` tinyint unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`,`progress_date`),
  KEY `idx_uldp_user_completed` (`user_id`,`goal_completed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_learn_daily_progress`
--

LOCK TABLES `user_learn_daily_progress` WRITE;
/*!40000 ALTER TABLE `user_learn_daily_progress` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_learn_daily_progress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_learn_daily_settings`
--

DROP TABLE IF EXISTS `user_learn_daily_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_learn_daily_settings` (
  `user_id` bigint unsigned NOT NULL,
  `daily_goal_xp` int unsigned NOT NULL DEFAULT '30',
  `timezone` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Asia/Ho_Chi_Minh',
  `streak_freeze_ready` tinyint unsigned NOT NULL DEFAULT '0',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_learn_daily_settings`
--

LOCK TABLES `user_learn_daily_settings` WRITE;
/*!40000 ALTER TABLE `user_learn_daily_settings` DISABLE KEYS */;
INSERT INTO `user_learn_daily_settings` VALUES (1,30,'Asia/Ho_Chi_Minh',0,'2026-10-14 07:20:19'),(3,30,'Asia/Ho_Chi_Minh',0,'2026-10-15 03:10:22');
/*!40000 ALTER TABLE `user_learn_daily_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_learn_exercise_attempts`
--

DROP TABLE IF EXISTS `user_learn_exercise_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_learn_exercise_attempts` (
  `attempt_key` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `lesson_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_revision` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `skill_key` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exercise_type` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activity_stage` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `difficulty` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_correct` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`attempt_key`),
  KEY `idx_ulea_user_lesson` (`user_id`,`lesson_id`),
  KEY `idx_ulea_user_skill` (`user_id`,`skill_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_learn_exercise_attempts`
--

LOCK TABLES `user_learn_exercise_attempts` WRITE;
/*!40000 ALTER TABLE `user_learn_exercise_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_learn_exercise_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_learn_lesson_mix_session`
--

DROP TABLE IF EXISTS `user_learn_lesson_mix_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_learn_lesson_mix_session` (
  `mix_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `lesson_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mix_fingerprint` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `questions_json` json NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` datetime NOT NULL,
  PRIMARY KEY (`mix_id`),
  UNIQUE KEY `uq_ulms_user_lesson` (`user_id`,`lesson_id`),
  KEY `idx_ulms_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_learn_lesson_mix_session`
--

LOCK TABLES `user_learn_lesson_mix_session` WRITE;
/*!40000 ALTER TABLE `user_learn_lesson_mix_session` DISABLE KEYS */;
INSERT INTO `user_learn_lesson_mix_session` VALUES ('81507d976476e76424bbd8875a0a2347',1,'p1-g1-n01','2070122f17a9525a4b439671751be60e473aac9c0fdef5c891499c1b009bd76a','[{\"id\": \"mix-p1-g1-n01-p1-g1-n01-a01-practice\", \"type\": \"listening_choice\", \"prompt\": \"Nghe và chọn hình đúng.\", \"options\": [{\"id\": \"a\", \"text\": \"name\", \"imageUrl\": \"https://static.arasaac.org/pictograms/27357/27357_500.png\", \"meaningVi\": \"tên\"}, {\"id\": \"b\", \"text\": \"thanks\", \"imageUrl\": \"https://static.arasaac.org/pictograms/38783/38783_500.png\", \"meaningVi\": \"cảm ơn\"}, {\"id\": \"c\", \"text\": \"night\", \"imageUrl\": \"https://static.arasaac.org/pictograms/26997/26997_500.png\", \"meaningVi\": \"buổi tối\"}, {\"id\": \"d\", \"text\": \"morning\", \"imageUrl\": \"https://static.arasaac.org/pictograms/25704/25704_500.png\", \"meaningVi\": \"buổi sáng\"}], \"ttsText\": \"name\", \"required\": true, \"extensions\": {\"ttsText\": \"name\", \"activity\": 1, \"modality\": \"listening\", \"evidenceRole\": \"recognition\", \"gradingTarget\": \"name\", \"contentRevision\": \"p1g1-r3\", \"integratedLesson\": true, \"choicePresentation\": \"picture\"}, \"reviewMeta\": {\"sourceLessonId\": \"p1-g1-n01\", \"sourceLessonType\": \"vocabulary\", \"sourceQuestionId\": \"p1-g1-n01-a01\"}, \"skillLabel\": \"Nghe và chọn hình\", \"explanation\": \"name nghĩa là tên.\", \"activityMeta\": {\"stage\": \"practice\", \"required\": true, \"skillKey\": \"listening\", \"difficulty\": \"medium\", \"sourceLessonId\": \"p1-g1-n01\", \"sourceLessonType\": \"vocabulary\", \"sourceQuestionId\": \"p1-g1-n01-a01\"}, \"correctAnswer\": \"a\"}, {\"id\": \"mix-p1-g1-n01-p1-g1-n01-a02-practice\", \"type\": \"multiple_choice\", \"prompt\": \"\\\"hello\\\" nghĩa là gì?\", \"options\": [{\"id\": \"a\", \"text\": \"xin chào\"}, {\"id\": \"b\", \"text\": \"buổi tối\"}, {\"id\": \"c\", \"text\": \"cảm ơn\"}, {\"id\": \"d\", \"text\": \"buổi sáng\"}], \"required\": true, \"extensions\": {\"ttsText\": \"hello\", \"activity\": 2, \"evidenceRole\": \"recognition\", \"meaningChoice\": true, \"contentRevision\": \"p1g1-r3\", \"integratedLesson\": true, \"meaningDirection\": \"en-to-vi\"}, \"reviewMeta\": {\"sourceLessonId\": \"p1-g1-n01\", \"sourceLessonType\": \"vocabulary\", \"sourceQuestionId\": \"p1-g1-n01-a02\"}, \"skillLabel\": \"Chọn nghĩa đúng\", \"explanation\": \"«hello» nghĩa là «xin chào», không phải «cảm ơn».\", \"activityMeta\": {\"stage\": \"practice\", \"required\": true, \"skillKey\": \"vocabulary\", \"difficulty\": \"medium\", \"sourceLessonId\": \"p1-g1-n01\", \"sourceLessonType\": \"vocabulary\", \"sourceQuestionId\": \"p1-g1-n01-a02\"}, \"correctAnswer\": \"a\"}, {\"id\": \"mix-p1-g1-n01-p1-g1-n01-a03-practice\", \"type\": \"matching_pairs\", \"pairs\": [{\"en\": \"hello\", \"vi\": \"xin chào\", \"pairId\": \"pair-1-hello\"}, {\"en\": \"morning\", \"vi\": \"buổi sáng\", \"pairId\": \"pair-2-morning\"}, {\"en\": \"thanks\", \"vi\": \"cảm ơn\", \"pairId\": \"pair-3-thanks\"}, {\"en\": \"name\", \"vi\": \"tên\", \"pairId\": \"pair-4-name\"}], \"prompt\": \"Ghép từ tiếng Anh với nghĩa tiếng Việt.\", \"required\": true, \"extensions\": {\"ttsText\": \"\", \"activity\": 3, \"evidenceRole\": \"recognition\", \"contentRevision\": \"p1g1-r3\", \"integratedLesson\": true}, \"reviewMeta\": {\"sourceLessonId\": \"p1-g1-n01\", \"sourceLessonType\": \"vocabulary\", \"sourceQuestionId\": \"p1-g1-n01-a03\"}, \"skillLabel\": \"Ghép từ Anh–Việt\", \"explanation\": \"Ghép từng từ với đúng một nghĩa.\", \"activityMeta\": {\"stage\": \"practice\", \"required\": true, \"skillKey\": \"vocabulary\", \"difficulty\": \"medium\", \"sourceLessonId\": \"p1-g1-n01\", \"sourceLessonType\": \"vocabulary\", \"sourceQuestionId\": \"p1-g1-n01-a03\"}}, {\"id\": \"mix-p1-g1-n01-p1-g1-n01-a04-practice\", \"type\": \"matching_pairs\", \"pairs\": [{\"en\": \"name\", \"vi\": \"tên\", \"pairId\": \"sound-1-name\"}, {\"en\": \"morning\", \"vi\": \"buổi sáng\", \"pairId\": \"sound-2-morning\"}, {\"en\": \"thanks\", \"vi\": \"cảm ơn\", \"pairId\": \"sound-3-thanks\"}, {\"en\": \"hello\", \"vi\": \"xin chào\", \"pairId\": \"sound-4-hello\"}], \"prompt\": \"Nghe và ghép với từ tiếng Anh. Bấm Nghe không bị tính là chọn.\", \"required\": true, \"extensions\": {\"ttsText\": \"\", \"activity\": 4, \"audioMatch\": true, \"evidenceRole\": \"recognition\", \"contentRevision\": \"p1g1-r3\", \"integratedLesson\": true}, \"reviewMeta\": {\"sourceLessonId\": \"p1-g1-n01\", \"sourceLessonType\": \"vocabulary\", \"sourceQuestionId\": \"p1-g1-n01-a04\"}, \"skillLabel\": \"Ghép âm thanh với từ\", \"explanation\": \"Nghe rồi chọn từ đúng. Lỗi phát âm thanh không bị tính là trả lời sai.\", \"activityMeta\": {\"stage\": \"practice\", \"required\": true, \"skillKey\": \"vocabulary\", \"difficulty\": \"medium\", \"sourceLessonId\": \"p1-g1-n01\", \"sourceLessonType\": \"vocabulary\", \"sourceQuestionId\": \"p1-g1-n01-a04\"}}, {\"id\": \"mix-p1-g1-n01-p1-g1-n01-a05-practice\", \"type\": \"word_order\", \"prompt\": \"Sắp xếp thành câu: «Xin chào, tôi là Beego.»\", \"required\": true, \"wordBank\": [\"Hello\", \"I\", \"am\", \"Beego\", \"name\", \"morning\"], \"extensions\": {\"meaning\": \"Xin chào, tôi là Beego.\", \"ttsText\": \"\", \"activity\": 5, \"evidenceRole\": \"application\", \"modelSentence\": \"Hello I am Beego.\", \"contentRevision\": \"p1g1-r3\", \"integratedLesson\": true}, \"reviewMeta\": {\"sourceLessonId\": \"p1-g1-n01\", \"sourceLessonType\": \"vocabulary\", \"sourceQuestionId\": \"p1-g1-n01-a05\"}, \"skillLabel\": \"Sắp xếp từ\", \"explanation\": \"Hello I am Beego.\", \"activityMeta\": {\"stage\": \"practice\", \"required\": true, \"skillKey\": \"sentence_patterns\", \"difficulty\": \"medium\", \"sourceLessonId\": \"p1-g1-n01\", \"sourceLessonType\": \"vocabulary\", \"sourceQuestionId\": \"p1-g1-n01-a05\"}, \"correctAnswer\": [\"Hello\", \"I\", \"am\", \"Beego\"]}, {\"id\": \"mix-p1-g1-n01-p1-g1-n01-a06-practice\", \"type\": \"listening_fill\", \"prompt\": \"Nghe và chọn từ còn thiếu.\", \"options\": [{\"id\": \"a\", \"text\": \"Hello\"}, {\"id\": \"b\", \"text\": \"name\"}, {\"id\": \"c\", \"text\": \"night\"}, {\"id\": \"d\", \"text\": \"thanks\"}], \"ttsText\": \"Hello Beego.\", \"required\": true, \"extensions\": {\"gapWord\": \"Hello\", \"meaning\": \"xin chào\", \"ttsText\": \"Hello Beego.\", \"activity\": 6, \"gapIndex\": 0, \"modality\": \"listening\", \"transcript\": \"Hello Beego.\", \"evidenceRole\": \"recognition\", \"gradingTarget\": \"Hello Beego.\", \"contentRevision\": \"p1g1-r3\", \"integratedLesson\": true}, \"reviewMeta\": {\"sourceLessonId\": \"p1-g1-n01\", \"sourceLessonType\": \"vocabulary\", \"sourceQuestionId\": \"p1-g1-n01-a06\"}, \"skillLabel\": \"Nghe và chọn từ còn thiếu\", \"explanation\": \"«Hello» nghĩa là xin chào\", \"activityMeta\": {\"stage\": \"practice\", \"required\": true, \"skillKey\": \"listening\", \"difficulty\": \"medium\", \"sourceLessonId\": \"p1-g1-n01\", \"sourceLessonType\": \"vocabulary\", \"sourceQuestionId\": \"p1-g1-n01-a06\"}, \"correctAnswer\": \"a\", \"sentenceTemplate\": \"___ Beego.\"}, {\"id\": \"mix-p1-g1-n01-p1-g1-n01-a07-practice\", \"type\": \"listening_dictation\", \"prompt\": \"Nghe và nhập lại câu.\", \"ttsText\": \"I am Beego. Hello.\", \"required\": true, \"extensions\": {\"meaning\": \"\", \"ttsText\": \"I am Beego. Hello.\", \"activity\": 7, \"hintMode\": \"count\", \"modality\": \"listening\", \"wordCount\": 4, \"transcript\": \"I am Beego. Hello.\", \"evidenceRole\": \"recognition\", \"gradingTarget\": \"I am Beego. Hello.\", \"contentRevision\": \"p1g1-r3\", \"listenDictation\": true, \"integratedLesson\": true}, \"reviewMeta\": {\"sourceLessonId\": \"p1-g1-n01\", \"sourceLessonType\": \"vocabulary\", \"sourceQuestionId\": \"p1-g1-n01-a07\"}, \"skillLabel\": \"Nghe và nhập lại câu\", \"explanation\": \"Gõ lại đúng câu đã nghe.\", \"activityMeta\": {\"stage\": \"practice\", \"required\": true, \"skillKey\": \"listening\", \"difficulty\": \"medium\", \"sourceLessonId\": \"p1-g1-n01\", \"sourceLessonType\": \"vocabulary\", \"sourceQuestionId\": \"p1-g1-n01-a07\"}, \"correctAnswer\": \"I am Beego. Hello.\"}, {\"id\": \"mix-p1-g1-n01-p1-g1-n01-a08-practice\", \"type\": \"translation\", \"prompt\": \"Dịch sang tiếng Anh.\", \"required\": true, \"wordBank\": [\"Hello\", \"name\", \"morning\", \"night\"], \"extensions\": {\"context\": \"\", \"ttsText\": \"\", \"activity\": 8, \"inputMode\": \"tiles\", \"speakText\": \"Hello.\", \"sourceText\": \"Xin chào.\", \"activityPart\": 1, \"evidenceRole\": \"application\", \"modelSentence\": \"Hello\", \"contentRevision\": \"p1g1-r3\", \"integratedLesson\": true, \"translationDirection\": \"vi-to-en\"}, \"reviewMeta\": {\"sourceLessonId\": \"p1-g1-n01\", \"sourceLessonType\": \"vocabulary\", \"sourceQuestionId\": \"p1-g1-n01-a08\"}, \"skillLabel\": \"Dịch sang tiếng Anh\", \"explanation\": \"Bài chấm các câu đã biên soạn. Đây là một cách nói tự nhiên, không phải cách đúng duy nhất.\", \"activityMeta\": {\"stage\": \"practice\", \"required\": true, \"skillKey\": \"sentence_patterns\", \"difficulty\": \"medium\", \"sourceLessonId\": \"p1-g1-n01\", \"sourceLessonType\": \"vocabulary\", \"sourceQuestionId\": \"p1-g1-n01-a08\"}, \"correctAnswer\": [\"Hello\"], \"acceptedAnswers\": [\"Hello\"]}, {\"id\": \"mix-p1-g1-n01-p1-g1-n01-a09-practice\", \"type\": \"translation\", \"prompt\": \"Dịch sang tiếng Việt.\", \"required\": true, \"wordBank\": [\"Tôi\", \"tên\", \"là\", \"Beego\", \"chào\", \"buổi\", \"sáng\"], \"extensions\": {\"context\": \"\", \"ttsText\": \"\", \"activity\": 8, \"inputMode\": \"tiles\", \"speakText\": \"My name is Beego.\", \"sourceText\": \"My name is Beego.\", \"activityPart\": 2, \"evidenceRole\": \"application\", \"modelSentence\": \"Tôi tên là Beego.\", \"contentRevision\": \"p1g1-r3\", \"integratedLesson\": true, \"translationDirection\": \"en-to-vi\"}, \"reviewMeta\": {\"sourceLessonId\": \"p1-g1-n01\", \"sourceLessonType\": \"vocabulary\", \"sourceQuestionId\": \"p1-g1-n01-a09\"}, \"skillLabel\": \"Dịch sang tiếng Việt\", \"explanation\": \"Có thể nói tên bằng My name is hoặc I am. Đây là một cách nói tự nhiên, không phải cách đúng duy nhất.\", \"activityMeta\": {\"stage\": \"practice\", \"required\": true, \"skillKey\": \"sentence_patterns\", \"difficulty\": \"medium\", \"sourceLessonId\": \"p1-g1-n01\", \"sourceLessonType\": \"vocabulary\", \"sourceQuestionId\": \"p1-g1-n01-a09\"}, \"correctAnswer\": [\"Tôi\", \"tên\", \"là\", \"Beego\"], \"acceptedAnswers\": [\"Tôi tên là Beego\", \"Tôi là Beego\", \"Tên tôi là Beego\"]}, {\"id\": \"mix-p1-g1-n01-p1-g1-n01-a10-practice\", \"type\": \"context_cloze\", \"prompt\": \"Đọc tình huống và điền từ còn thiếu.\", \"options\": [{\"id\": \"a\", \"text\": \"Sorry\"}, {\"id\": \"b\", \"text\": \"Thanks\"}, {\"id\": \"c\", \"text\": \"Hello\"}, {\"id\": \"d\", \"text\": \"Goodbye\"}], \"required\": true, \"extensions\": {\"answers\": [\"Hello\"], \"blankId\": \"p1-n01-cloze\", \"ttsText\": \"\", \"activity\": 9, \"gapIndex\": 2, \"inputMode\": \"choice\", \"contextCloze\": true, \"evidenceRole\": \"application\", \"contentRevision\": \"p1g1-r3\", \"integratedLesson\": true, \"completedSentence\": \"Beego says Hello to Mai.\"}, \"reviewMeta\": {\"sourceLessonId\": \"p1-g1-n01\", \"sourceLessonType\": \"vocabulary\", \"sourceQuestionId\": \"p1-g1-n01-a10\"}, \"skillLabel\": \"Điền theo tình huống\", \"explanation\": \"Khi mới gặp, lời chào là Hello.\", \"activityMeta\": {\"stage\": \"practice\", \"required\": true, \"skillKey\": \"grammar\", \"difficulty\": \"medium\", \"sourceLessonId\": \"p1-g1-n01\", \"sourceLessonType\": \"vocabulary\", \"sourceQuestionId\": \"p1-g1-n01-a10\"}, \"correctAnswer\": \"c\", \"sentenceTemplate\": \"Beego says ___ to Mai.\"}, {\"id\": \"mix-p1-g1-n01-p1-g1-n01-a11-practice\", \"type\": \"dialogue_response\", \"prompt\": \"Chọn câu đáp để hoàn thành hội thoại.\", \"options\": [{\"id\": \"a\", \"text\": \"Hello. I am Beego.\"}, {\"id\": \"b\", \"text\": \"Thank you very much.\"}, {\"id\": \"c\", \"text\": \"Good night.\"}, {\"id\": \"d\", \"text\": \"See you later.\"}], \"required\": true, \"extensions\": {\"lines\": [{\"text\": \"You meet Mai for the first time. What do you say?\", \"avatar\": \"👩\", \"turnId\": \"p1-n01-ask\", \"pending\": false, \"speaker\": \"Mai\"}, {\"text\": \"\", \"avatar\": \"🐝\", \"turnId\": \"p1-n01-you\", \"pending\": true, \"speaker\": \"Beego\"}], \"reply\": \"Hello. I am Beego.\", \"blankId\": \"p1-n01-talk\", \"ttsText\": \"\", \"activity\": 10, \"followUp\": {\"text\": \"Nice to meet you.\", \"avatar\": \"👩\", \"turnId\": \"p1-n01-next\", \"pending\": false, \"speaker\": \"Mai\"}, \"situation\": \"p1-n01\", \"evidenceRole\": \"application\", \"contentRevision\": \"p1g1-r3\", \"dialogueResponse\": true, \"integratedLesson\": true}, \"reviewMeta\": {\"sourceLessonId\": \"p1-g1-n01\", \"sourceLessonType\": \"vocabulary\", \"sourceQuestionId\": \"p1-g1-n01-a11\"}, \"skillLabel\": \"Chọn câu đáp\", \"explanation\": \"Lần đầu gặp thì chào và nói mình là ai.\", \"activityMeta\": {\"stage\": \"practice\", \"required\": true, \"skillKey\": \"comprehension\", \"difficulty\": \"medium\", \"sourceLessonId\": \"p1-g1-n01\", \"sourceLessonType\": \"vocabulary\", \"sourceQuestionId\": \"p1-g1-n01-a11\"}, \"correctAnswer\": \"a\"}, {\"id\": \"mix-p1-g1-n01-p1-g1-n01-a12-practice\", \"type\": \"speaking\", \"prompt\": \"Nghe và nhắc lại.\", \"minScore\": 65, \"required\": false, \"extensions\": {\"ttsText\": \"Hello. I am Beego.\", \"activity\": 11, \"modality\": \"speaking\", \"speakTarget\": \"Hello. I am Beego.\", \"evidenceRole\": \"practice\", \"contentRevision\": \"p1g1-r3\", \"integratedLesson\": true}, \"reviewMeta\": {\"sourceLessonId\": \"p1-g1-n01\", \"sourceLessonType\": \"vocabulary\", \"sourceQuestionId\": \"p1-g1-n01-a12\"}, \"skillLabel\": \"Đọc thành tiếng\", \"explanation\": \"Câu cần nói: Hello. I am Beego.\", \"speakTarget\": \"Hello. I am Beego.\", \"activityMeta\": {\"stage\": \"practice\", \"required\": false, \"skillKey\": \"speaking\", \"difficulty\": \"medium\", \"sourceLessonId\": \"p1-g1-n01\", \"sourceLessonType\": \"vocabulary\", \"sourceQuestionId\": \"p1-g1-n01-a12\"}}, {\"id\": \"mix-p1-g1-n01-p1-g1-n01-a13-challenge\", \"type\": \"story_comprehension\", \"prompt\": \"Beego chào Mai bằng câu nào?\", \"options\": [{\"id\": \"a\", \"text\": \"Hello I am Beego\"}, {\"id\": \"b\", \"text\": \"See you later\"}, {\"id\": \"c\", \"text\": \"Good night\"}, {\"id\": \"d\", \"text\": \"Thank you\"}], \"storyVi\": \"Beego nói Hello I am Beego với Mai.\", \"required\": true, \"storyText\": \"Hello Mai. I am Beego.\", \"extensions\": {\"storyVi\": \"Beego nói Hello I am Beego với Mai.\", \"ttsText\": \"Hello Mai. I am Beego.\", \"activity\": 12, \"modality\": \"story\", \"storyText\": \"Hello Mai. I am Beego.\", \"evidenceRole\": \"recognition\", \"evaluationTurn\": true, \"learnerSupport\": \"after-grade\", \"contentRevision\": \"p1g1-r3\", \"integratedLesson\": true}, \"reviewMeta\": {\"sourceLessonId\": \"p1-g1-n01\", \"sourceLessonType\": \"vocabulary\", \"sourceQuestionId\": \"p1-g1-n01-a13\"}, \"skillLabel\": \"Đọc đoạn\", \"explanation\": \"Đoạn văn trả lời: Hello I am Beego\", \"activityMeta\": {\"stage\": \"challenge\", \"required\": true, \"skillKey\": \"comprehension\", \"difficulty\": \"medium\", \"sourceLessonId\": \"p1-g1-n01\", \"sourceLessonType\": \"vocabulary\", \"sourceQuestionId\": \"p1-g1-n01-a13\"}, \"correctAnswer\": \"a\"}]','2026-10-14 07:23:03','2026-10-15 14:23:03');
/*!40000 ALTER TABLE `user_learn_lesson_mix_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_learn_mastery_rollup_events`
--

DROP TABLE IF EXISTS `user_learn_mastery_rollup_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_learn_mastery_rollup_events` (
  `event_key` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `lesson_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`event_key`),
  KEY `idx_ulmre_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_learn_mastery_rollup_events`
--

LOCK TABLES `user_learn_mastery_rollup_events` WRITE;
/*!40000 ALTER TABLE `user_learn_mastery_rollup_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_learn_mastery_rollup_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_learn_mistakes`
--

DROP TABLE IF EXISTS `user_learn_mistakes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_learn_mistakes` (
  `user_id` bigint unsigned NOT NULL,
  `lesson_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `skill_key` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exercise_type` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('open','resolved') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `wrong_count` int unsigned NOT NULL DEFAULT '0',
  `correct_recovery_count` int unsigned NOT NULL DEFAULT '0',
  `last_wrong_at` datetime DEFAULT NULL,
  `last_correct_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`,`lesson_id`,`question_id`),
  KEY `idx_ulm_user_skill_open` (`user_id`,`skill_key`,`status`),
  KEY `idx_ulm_user_open` (`user_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_learn_mistakes`
--

LOCK TABLES `user_learn_mistakes` WRITE;
/*!40000 ALTER TABLE `user_learn_mistakes` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_learn_mistakes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_learn_placement_results`
--

DROP TABLE IF EXISTS `user_learn_placement_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_learn_placement_results` (
  `user_id` bigint unsigned NOT NULL,
  `session_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `placement_score` decimal(5,2) NOT NULL DEFAULT '0.00',
  `estimated_level` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'A0',
  `strengths_json` json DEFAULT NULL,
  `weak_skills_json` json DEFAULT NULL,
  `confidence` decimal(5,3) NOT NULL DEFAULT '0.000',
  `recommended_lesson_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_choice` enum('recommended','from_start','skipped') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `placement_start_lesson_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `completed_at` datetime NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  KEY `idx_ulpr_lesson` (`recommended_lesson_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_learn_placement_results`
--

LOCK TABLES `user_learn_placement_results` WRITE;
/*!40000 ALTER TABLE `user_learn_placement_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_learn_placement_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_learn_recommendation_cache`
--

DROP TABLE IF EXISTS `user_learn_recommendation_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_learn_recommendation_cache` (
  `user_id` bigint unsigned NOT NULL,
  `payload_json` json NOT NULL,
  `input_fingerprint` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  KEY `idx_ulrc_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_learn_recommendation_cache`
--

LOCK TABLES `user_learn_recommendation_cache` WRITE;
/*!40000 ALTER TABLE `user_learn_recommendation_cache` DISABLE KEYS */;
INSERT INTO `user_learn_recommendation_cache` VALUES (3,'{\"cached\": false, \"generatedAt\": \"2026-10-15T04:05:14.781Z\", \"inputsSummary\": {\"srsDue\": 0, \"streak\": 0, \"survey\": {\"focus\": \"\", \"purpose\": \"\", \"dailyMinutes\": null}, \"xpToday\": 0, \"dailyGoalXp\": 30, \"openMistakes\": 0, \"weakestSkill\": null, \"activeLessonId\": \"p1-g1-n01\", \"placementLevel\": null, \"progressionTier\": null, \"recentAccuracyPct\": null, \"dailyGoalCompleted\": false}, \"recommendations\": [{\"href\": \"/learn/lesson/p1-g1-n01\", \"rank\": 1, \"type\": \"daily_goal_completion\", \"title\": \"Chào một người mới\", \"lessonId\": \"p1-g1-n01\", \"priority\": 680, \"skillKey\": \"vocabulary\", \"slotHint\": \"primary\", \"slotLabel\": \"Nên học ngay\", \"reasonCode\": \"DAILY_GOAL_REMAINING\", \"reasonText\": \"Chưa đạt Daily Goal hôm nay (−30 XP)\", \"estimatedMinutes\": 12}]}','df2ea11d785e5cba4713e517cfa26b4b92f44d37149be7e33f5b34778d96ac6c','2026-10-15 11:06:00','2026-10-15 04:01:43','2026-10-15 04:05:14');
/*!40000 ALTER TABLE `user_learn_recommendation_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_learn_skill_mastery`
--

DROP TABLE IF EXISTS `user_learn_skill_mastery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_learn_skill_mastery` (
  `user_id` bigint unsigned NOT NULL,
  `skill_key` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `correct_count` int unsigned NOT NULL DEFAULT '0',
  `wrong_count` int unsigned NOT NULL DEFAULT '0',
  `attempts_count` int unsigned NOT NULL DEFAULT '0',
  `mastery_score` decimal(5,2) NOT NULL DEFAULT '0.00',
  `mastery_level` tinyint unsigned NOT NULL DEFAULT '0',
  `mastery_phase` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NEW',
  `accuracy_pct` decimal(5,2) NOT NULL DEFAULT '0.00',
  `last_practiced_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`,`skill_key`),
  KEY `idx_ulsm_user_score` (`user_id`,`mastery_score`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_learn_skill_mastery`
--

LOCK TABLES `user_learn_skill_mastery` WRITE;
/*!40000 ALTER TABLE `user_learn_skill_mastery` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_learn_skill_mastery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_learn_smart_progression`
--

DROP TABLE IF EXISTS `user_learn_smart_progression`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_learn_smart_progression` (
  `user_id` bigint unsigned NOT NULL,
  `progression_tier` enum('weak','medium','strong') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'medium',
  `recovery_priority` tinyint unsigned NOT NULL DEFAULT '50',
  `challenge_priority` tinyint unsigned NOT NULL DEFAULT '50',
  `primary_skill_key` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_lesson_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_learn_smart_progression`
--

LOCK TABLES `user_learn_smart_progression` WRITE;
/*!40000 ALTER TABLE `user_learn_smart_progression` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_learn_smart_progression` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_lesson_progress`
--

DROP TABLE IF EXISTS `user_lesson_progress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_lesson_progress` (
  `user_id` bigint unsigned NOT NULL,
  `lesson_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('active','completed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'completed',
  `score` decimal(5,2) DEFAULT NULL,
  `xp_awarded` int NOT NULL DEFAULT '0',
  `honey_awarded` int NOT NULL DEFAULT '0',
  `completed_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`,`lesson_id`),
  KEY `idx_ulp_user_status` (`user_id`,`status`),
  KEY `idx_ulp_completed` (`user_id`,`completed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_lesson_progress`
--

LOCK TABLES `user_lesson_progress` WRITE;
/*!40000 ALTER TABLE `user_lesson_progress` DISABLE KEYS */;
INSERT INTO `user_lesson_progress` VALUES (1,'p1-g1-n01','completed',NULL,0,0,'2026-10-09 10:58:25','2026-10-09 03:58:25','2026-10-09 03:58:25');
/*!40000 ALTER TABLE `user_lesson_progress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_review_events`
--

DROP TABLE IF EXISTS `user_review_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_review_events` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `attempt_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `word_id` bigint unsigned NOT NULL,
  `is_correct` tinyint(1) NOT NULL,
  `xp_delta` int NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_review_events_attempt` (`user_id`,`attempt_id`),
  KEY `idx_user_review_events_user_created` (`user_id`,`created_at`),
  KEY `fk_user_review_events_word` (`word_id`),
  CONSTRAINT `fk_user_review_events_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_user_review_events_word` FOREIGN KEY (`word_id`) REFERENCES `vocabulary` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_review_events`
--

LOCK TABLES `user_review_events` WRITE;
/*!40000 ALTER TABLE `user_review_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_review_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_sessions`
--

DROP TABLE IF EXISTS `user_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_sessions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `token` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `platform` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'web' COMMENT 'web|android|ios',
  `device_id` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refresh_token_hash` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked_at` datetime DEFAULT NULL,
  `last_seen_at` datetime DEFAULT NULL,
  `user_agent` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `idx_user_sessions_user_id` (`user_id`),
  KEY `idx_user_sessions_expires_at` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_sessions`
--

LOCK TABLES `user_sessions` WRITE;
/*!40000 ALTER TABLE `user_sessions` DISABLE KEYS */;
INSERT INTO `user_sessions` VALUES (1,1,'1ac2f8e98669ee10bff824dfaaa6411ba0905875f2ac51bcbd6ca417a3a0c5af','2026-10-16 10:58:49','2026-10-09 03:58:49','web',NULL,NULL,NULL,'2026-10-09 10:58:50',NULL),(2,1,'2dfa14669ed805a2d364833ec87a4c87617c7e0a7e6a4115e6fe8419cffef444','2026-10-16 10:59:36','2026-10-09 03:59:35','web',NULL,NULL,NULL,'2026-10-09 10:59:36',NULL),(3,1,'745e92fc762b4940ede4d1607c9182467bd08bbc8ab99eb9982b5768ed286209','2026-10-16 11:16:53','2026-10-09 04:16:53','web',NULL,NULL,NULL,'2026-10-09 11:16:54',NULL),(4,1,'49c9ae561cd298bfeccdd5b70ab6cf8af7e4498fcfa867453b0ed6a75197d86c','2026-10-16 11:34:36','2026-10-09 04:34:35','web',NULL,NULL,NULL,'2026-10-09 11:34:45',NULL),(5,1,'750b90a15dc8b6d7894fec66c6e37db6f1d8a8ddc344b301e619f5a0d68785e7','2026-10-16 11:48:22','2026-10-09 04:48:22','web',NULL,NULL,NULL,NULL,NULL),(6,1,'d3aa24ff683466e7d1ca57527df5db5254da6223e7b199f829f6cf7a99fc350f','2026-10-16 11:48:41','2026-10-09 04:48:41','web',NULL,NULL,NULL,'2026-10-09 11:48:46',NULL),(7,1,'dda8a27663f6db3f9a2c3e7a4c5f3a2a6272ed9c6a164499c0c6dcd33a54a5b0','2026-10-21 14:17:52','2026-10-14 07:17:52','web',NULL,NULL,NULL,NULL,NULL),(8,1,'bb84e38f4b53eef923a275b5b49aaf2ff299e67cdbaed7046fa532259b765416','2026-10-21 14:18:03','2026-10-14 07:18:03','web',NULL,NULL,NULL,NULL,NULL),(9,1,'d2b88ad694597e360c302daf262abe7720576fb91dd8d12ddbbeb39b3f0a5cbf','2026-10-21 14:18:48','2026-10-14 07:18:48','web',NULL,NULL,NULL,NULL,NULL),(10,1,'7b273e0fc2fa0b737a539c7c73c046dd17099ab56099609e3429d9d37b4ee8d8','2026-10-21 14:20:19','2026-10-14 07:20:18','web',NULL,NULL,NULL,NULL,NULL),(11,1,'79c700f364982fea077d3e5d725a5fe3849cf499ebe11cc2d75dce83eee91b82','2026-10-21 14:20:31','2026-10-14 07:20:31','web',NULL,NULL,NULL,NULL,NULL),(12,1,'d3e59f94d50b149cc076a31f37681bea27e4600bbc16a445f5b1fb010fc7e979','2026-10-21 14:20:37','2026-10-14 07:20:36','web',NULL,NULL,NULL,NULL,NULL),(13,1,'8c9e1eaf320d65604bd4e77ce98b3e8ae8a07e7eebdfaad3d231fc591f8043d5','2026-10-21 14:20:43','2026-10-14 07:20:42','web',NULL,NULL,NULL,NULL,NULL),(14,1,'e4b0b3b2121637bb8273c48a1755004725aac998aff190aecb096e874cea638d','2026-10-21 14:22:32','2026-10-14 07:22:31','web',NULL,NULL,NULL,NULL,NULL),(15,1,'7c6decafd34d9483ab4451d7a07fb40353f981cfeb6cb58106f4ea209a3b8155','2026-10-21 14:23:01','2026-10-14 07:23:00','web',NULL,NULL,NULL,'2026-10-14 14:23:03',NULL),(16,1,'3eb5c8f058aa08f5c8a361d0f2d1a48f681b139fa7f07fd137477c30771b74de','2026-10-21 14:25:02','2026-10-14 07:25:02','web',NULL,NULL,NULL,'2026-10-14 14:25:04',NULL),(17,1,'13b414ed5e4ebb77a818032b7de74c053667534ebbbadcdae39341439d52a68c','2026-10-21 14:26:34','2026-10-14 07:26:34','web',NULL,NULL,NULL,'2026-10-14 14:26:36',NULL),(18,1,'adf4364a0a7853f9cf610d941c8cb9a96c6f43ffc2d481e773ade528328999e7','2026-10-21 14:30:40','2026-10-14 07:30:40','web',NULL,NULL,NULL,'2026-10-14 14:30:47',NULL),(19,1,'3be8077986903426d52d666c42ea0df7047a44ac0ee1938e446f6af7d3ef802e','2026-10-21 14:32:27','2026-10-14 07:32:26','web',NULL,NULL,NULL,'2026-10-14 14:32:29',NULL),(20,1,'51fd07dbb5bc6bcad06de65649cd6b16538096baaecd9bf10174487bb1778806','2026-10-21 14:33:31','2026-10-14 07:33:30','web',NULL,NULL,NULL,'2026-10-14 14:33:32',NULL),(21,1,'0de2960b126e8d99dfa87d92d5abfe138c3b51de2fdd3b90ab2ffc4f52fb0742','2026-10-21 14:39:20','2026-10-14 07:39:19','web',NULL,NULL,NULL,'2026-10-14 14:39:22',NULL),(22,1,'39832a525d88f9b9d05e14e5e52cccf2122bddf61d28a54e6c2d6dcfd56a07f7','2026-10-21 14:40:11','2026-10-14 07:40:11','web',NULL,NULL,NULL,'2026-10-14 14:40:13',NULL),(23,1,'a568c9ba5a00c7af71f527d8b32fa9f50b4d7cf6225493eec6560863f0bdc294','2026-10-21 14:42:30','2026-10-14 07:42:30','web',NULL,NULL,NULL,NULL,NULL),(24,1,'e2e39fef26fb5a84d4582ab6639b16362018e3ef9b25496a3422224c4c8d4af0','2026-10-21 14:42:37','2026-10-14 07:42:36','web',NULL,NULL,NULL,NULL,NULL),(25,2,'55db0fe4996aa217d3233e1e2d05d6c433bd79f359f3008c7655c93c8aed4e25','2026-10-21 17:27:52','2026-10-14 10:27:52','web',NULL,NULL,NULL,NULL,NULL),(26,1,'e354664a0d940723ebc16be800ac221be0b4d90740329552a32219f41ae5b857','2026-10-21 17:27:53','2026-10-14 10:27:52','web',NULL,NULL,NULL,NULL,NULL),(27,2,'984cf7bc6b9b75b3b516e040de3bf699231807425a7644ad6f049fb68906c553','2026-10-21 17:28:18','2026-10-14 10:28:17','web',NULL,NULL,NULL,NULL,NULL),(28,1,'128bbeb1ce94410232543b3b8ee778eaac77966f4746b4023da66a9ba769a2cb','2026-10-21 17:28:18','2026-10-14 10:28:17','web',NULL,NULL,NULL,NULL,NULL),(29,2,'b18e6b6aa8c8bb53a4026832e05fb0923493e54c5cbfc43d7ceab40438c4f4bb','2026-10-21 17:28:31','2026-10-14 10:28:31','web',NULL,NULL,NULL,NULL,NULL),(30,1,'3007c5782cce7eee7192ff96c37e1a4df404c0fc696f2344a9575ce58eefff9f','2026-10-21 17:28:31','2026-10-14 10:28:31','web',NULL,NULL,NULL,NULL,NULL),(31,2,'2a53cbbacbdcdaba221b5ba438a1787ef52c8292ee7281061200480022d8de1e','2026-10-21 17:30:42','2026-10-14 10:30:41','web',NULL,NULL,NULL,NULL,NULL),(32,1,'417f628f99bfb050f3ee23a30a520caadf7e44560c4dc4790a4efc2856aca92e','2026-10-21 17:30:42','2026-10-14 10:30:41','web',NULL,NULL,NULL,NULL,NULL),(33,2,'a72aa9642071c7f077bd1af4d9f4e3e4f55ec7ff94b18d3113a72e35328c5bac','2026-10-21 17:30:55','2026-10-14 10:30:55','web',NULL,NULL,NULL,NULL,NULL),(34,1,'58a565c0c642221ba554a4dc876fbca19aebd3d0628b63fa265b1d8248fd51e8','2026-10-21 17:30:56','2026-10-14 10:30:55','web',NULL,NULL,NULL,NULL,NULL),(35,2,'d828ddec7d1e756bf6ecb8608f7d17bef7f6c60bbd38973ec1d648910627cd63','2026-10-21 17:35:28','2026-10-14 10:35:27','web',NULL,NULL,NULL,NULL,NULL),(36,1,'7daaf12612ee39355d7e58766c7d56cf38153d21dd4437b01a6cc3eaa5566e28','2026-10-21 17:35:28','2026-10-14 10:35:27','web',NULL,NULL,NULL,NULL,NULL),(37,2,'cd03b4b2bd9cd389dab85153b9897eb503971ff5f07946309d3802705e79fb53','2026-10-21 17:35:34','2026-10-14 10:35:34','web',NULL,NULL,NULL,NULL,NULL),(38,1,'ff403c62f1bd91da2369ac8a14632a309cbdbdfe3021faeabdecf6d6d981f3f7','2026-10-21 17:35:34','2026-10-14 10:35:34','web',NULL,NULL,NULL,NULL,NULL),(39,1,'81555c4b18cf28fc57c12939d7c400f17717bc15a4a145ce752a30fadceb587b','2026-10-21 17:37:27','2026-10-14 10:37:27','web',NULL,NULL,NULL,NULL,NULL),(40,1,'75662226a2ac444a878b9472c4e0ce145210d76714696e525b64067113309b3f','2026-10-21 17:37:33','2026-10-14 10:37:33','web',NULL,NULL,NULL,'2026-10-14 17:37:45',NULL),(41,2,'1ca64dd4985d8a512bb735d2e3d333292aac854c6442c8fd45d6907c5234b93e','2026-10-21 17:38:51','2026-10-14 10:38:51','web',NULL,NULL,NULL,NULL,NULL),(42,1,'3a4a38cf4d3ac3b38df4f2b3c6186efe2b3450fb9db155dfcccdc08189ae1a67','2026-10-21 17:38:51','2026-10-14 10:38:51','web',NULL,NULL,NULL,NULL,NULL),(43,2,'0c1077bf328bdf0d7032e8c6edffdd63e592a8c1c19782f845e6662ed43a0d63','2026-10-21 17:38:56','2026-10-14 10:38:56','web',NULL,NULL,NULL,NULL,NULL),(44,1,'be8342980613a11a1208f18a1589fd3e00acd441e40cd49946243099f2ca6341','2026-10-21 17:38:56','2026-10-14 10:38:56','web',NULL,NULL,NULL,NULL,NULL),(45,3,'91dfdc8e601b633286fd5968b5e202a71a00d01fc1a61485d0fc06287a4b47c5','2026-10-22 10:10:22','2026-10-15 03:10:21','web',NULL,NULL,NULL,NULL,NULL),(46,2,'80e952fda0ed3dce62189fe30239a886126ddd126c277561fe9d3acf527c01ed','2026-10-22 10:10:22','2026-10-15 03:10:22','web',NULL,NULL,NULL,NULL,NULL),(47,3,'c740605e0c9c1f0760ec8277c324f30981e8aa540255bc569bb9baecce8e45e5','2026-10-22 10:22:08','2026-10-15 03:22:07','web',NULL,NULL,NULL,NULL,NULL),(48,2,'7cb6ac097b68dc367d5b29a6c07d5afc19cf7b6f012180630dd0ebb082778277','2026-10-22 10:22:08','2026-10-15 03:22:08','web',NULL,NULL,NULL,NULL,NULL),(49,3,'7467f76c88e5446031006189bceaf578ed902cb046d7c6d58471b12717f2d177','2026-10-22 10:49:37','2026-10-15 03:49:36','web',NULL,NULL,NULL,NULL,NULL),(50,3,'b9255fb7ff458e0cf453c7889fa0244fba145acefcf9282e98fa2cdc03bee8b4','2026-10-22 10:54:01','2026-10-15 03:54:00','web',NULL,NULL,NULL,NULL,NULL),(51,3,'e194de946e952662480d3a071012820e08a76f7f884d3f37136087cab4eba82c','2026-10-22 10:59:50','2026-10-15 03:59:49','web',NULL,NULL,NULL,NULL,NULL),(52,3,'0062b88e0828a372b99efabeaa43d0c79cc5d1628d52e9a69fdb8bbd683d8ca0','2026-10-22 11:00:53','2026-10-15 04:00:52','web',NULL,NULL,NULL,NULL,NULL),(53,3,'79a7a0bd641fbe78887343f7b6ef67cea4ff86768738ca3b93a22348e624a5ba','2026-10-22 11:01:39','2026-10-15 04:01:39','web',NULL,NULL,NULL,'2026-10-15 11:01:42',NULL),(54,3,'9e3282dd761839492a83e8d1fe2dcb3d45d0ad03fe5394ffca7d272f7f8cb603','2026-10-22 11:05:10','2026-10-15 04:05:10','web',NULL,NULL,NULL,'2026-10-15 11:05:14',NULL),(55,3,'90427f3ecbe68a941b60591ab934671bdb89f53f4845b730c2fae2af99ad0e93','2026-10-22 16:30:15','2026-10-15 09:30:14','web',NULL,NULL,NULL,NULL,NULL),(56,2,'1a4c85ed737f0966120f5c08c229de1fb9e581f85441de4e818200ffdeb4c736','2026-10-22 16:30:16','2026-10-15 09:30:15','web',NULL,NULL,NULL,NULL,NULL),(57,3,'22998deceaa616ba6c987d666af4ea42369ecacb49e6a465f4b9ff0a83a83f9f','2026-10-22 16:30:26','2026-10-15 09:30:26','web',NULL,NULL,NULL,NULL,NULL),(58,3,'a21143cb8970b9fa96a6acbd8c87f4b3f15f36c9bcbcca1faa00366306f4b821','2026-10-22 16:30:38','2026-10-15 09:30:38','web',NULL,NULL,NULL,NULL,NULL),(59,2,'5039a6308b8f54fcfca23b403d526c3a64557267201fda413ba9b123138672d4','2026-10-22 16:30:39','2026-10-15 09:30:38','web',NULL,NULL,NULL,NULL,NULL),(60,3,'fd088eaba6fee21d730595372d7c24c8dbda2fbffae368967d0843de7e5494a4','2026-10-22 18:42:34','2026-10-15 11:42:33','web',NULL,NULL,NULL,NULL,NULL),(61,3,'07a044c4798d27ef2ffe37f4bed9035d96fe97a2537f141914feaad2a78c8209','2026-10-22 18:50:35','2026-10-15 11:50:35','web',NULL,NULL,NULL,NULL,NULL),(62,3,'9eb34c9f134ddee1a54929bcf32ec89dd753994e38defc89a02464753ef7c359','2026-10-22 18:56:54','2026-10-15 11:56:53','web',NULL,NULL,NULL,NULL,NULL),(63,2,'162b67b1af3e911dbfe34a6b9ec9c2040408fb35db97ce1f412ed720f41f83df','2026-10-22 18:56:54','2026-10-15 11:56:54','web',NULL,NULL,NULL,NULL,NULL),(64,3,'ac76b307b5df4f00755b3b668e0234595fc183c65e0c95cdbd9412738513ee6e','2026-10-22 20:15:01','2026-10-15 13:15:00','web',NULL,NULL,NULL,NULL,NULL),(65,2,'263c223b07fe96a8291ce359ef77659e1b61cfff4bb3ea99a073eaf0eb3a9215','2026-10-22 20:15:02','2026-10-15 13:15:01','web',NULL,NULL,NULL,NULL,NULL),(66,3,'84fae07193aa3b2c0e8866cad7bb94b759c29f67c3ea77e78bc3fea31dbbb253','2026-10-22 22:21:01','2026-10-15 15:21:00','web',NULL,NULL,NULL,NULL,NULL),(67,2,'708bcc2c58dab9cec752ea1d7e0bccead798fb1c0933113c489423ddb5b09030','2026-10-22 22:21:01','2026-10-15 15:21:01','web',NULL,NULL,NULL,NULL,NULL),(68,3,'a83290a8263d8ce65f6d451e7c3cc53b1c17fea72d89550e3530b583bc7a6073','2026-10-22 22:58:09','2026-10-15 15:58:09','web',NULL,NULL,NULL,NULL,NULL),(69,2,'7146ece5911905ccf0888843a1feb4a20f2d2a248dbf0978d4d0bd14a6fa7ab1','2026-10-22 22:58:10','2026-10-15 15:58:09','web',NULL,NULL,NULL,NULL,NULL),(70,3,'42f930849ed7010dd66191e13097b19b243fd9efd22c7d758e3c00e1391030d4','2026-10-22 23:27:51','2026-10-15 16:27:51','web',NULL,NULL,NULL,NULL,NULL),(71,3,'50ed95e9b06df3a2ecebbf53d9b841be102058bdd5c852e6681e0d4cf1b5205d','2026-10-23 09:28:34','2026-10-16 02:28:33','web',NULL,NULL,NULL,NULL,NULL),(72,3,'88f7a3ab0f4bcbebb6596151841729b84ebb5d6e60321cf6b03484ff58259cf8','2026-10-23 09:37:27','2026-10-16 02:37:27','web',NULL,NULL,NULL,NULL,NULL),(73,2,'477a1f4aaac65533d5d95e09aa29978a390a850d76a201663f0a7258591258e9','2026-10-23 09:37:30','2026-10-16 02:37:30','web',NULL,NULL,NULL,NULL,NULL),(74,3,'775c725e6e5762db5d072a3448de621a78c250f72d35330c5162aff7d80b91ce','2026-10-23 14:28:10','2026-10-16 07:28:09','web',NULL,NULL,NULL,'2026-10-16 14:28:10',NULL),(75,3,'a74096374fb50d986cee7d3a242923b233ce5b3f5f6dc2801597b091cb45927e','2026-10-23 14:28:24','2026-10-16 07:28:23','web',NULL,NULL,NULL,NULL,NULL),(76,3,'4e2b70d26ca22a71d5808f0408fba2f461410f6196a8cc07ee1a63fa69e91e05','2026-10-23 14:28:37','2026-10-16 07:28:36','web',NULL,NULL,NULL,NULL,NULL),(77,3,'33e862575fb075a623047347fb9f05426b90cd7a1497654802dee93bcd88119f','2026-10-23 14:37:18','2026-10-16 07:37:18','web',NULL,NULL,NULL,NULL,NULL),(78,2,'84b17f5d9ca1139a4569ab3c35f7cdac60d882bf2370d34e6f3384662394c324','2026-10-23 14:37:21','2026-10-16 07:37:21','web',NULL,NULL,NULL,NULL,NULL),(79,3,'02a7231e13bdbcd08e1a011d753fc25ff2915d0fb2f21df66eee693733756b54','2026-10-23 14:45:37','2026-10-16 07:45:37','web',NULL,NULL,NULL,'2026-10-16 14:45:37',NULL),(80,3,'77ef954bfaa1de1ba36cfd9fac6d00a5cb2ad600e521c46460fdc268df73ff3a','2026-10-23 14:51:35','2026-10-16 07:51:34','web',NULL,NULL,NULL,NULL,NULL),(81,2,'6d7f5ab9454b0007d3ca0cffe023fea7bf9f8487f5b0706ac5cdc641fabb5c73','2026-10-23 14:51:35','2026-10-16 07:51:35','web',NULL,NULL,NULL,NULL,NULL),(82,3,'668e792f7d35031625a28304aa83a0b12678a0c2c35344c2e15917589c87aac3','2026-10-23 14:52:23','2026-10-16 07:52:22','web',NULL,NULL,NULL,'2026-10-16 14:52:23',NULL),(83,2,'9a3b8fe6c610932502c97c0433e1d7ba5a427080749a6ec84272721d8f5d3f21','2026-10-23 14:52:23','2026-10-16 07:52:23','web',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `user_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_stats`
--

DROP TABLE IF EXISTS `user_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_stats` (
  `user_id` bigint unsigned NOT NULL,
  `xp_total` int NOT NULL DEFAULT '0',
  `honey_total` int NOT NULL DEFAULT '0',
  `current_streak` int NOT NULL DEFAULT '0',
  `best_streak` int NOT NULL DEFAULT '0',
  `last_active_date` date DEFAULT NULL,
  `last_answer_at` datetime DEFAULT NULL,
  `active_lesson_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `placement_start_lesson_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `fk_user_stats_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_stats`
--

LOCK TABLES `user_stats` WRITE;
/*!40000 ALTER TABLE `user_stats` DISABLE KEYS */;
INSERT INTO `user_stats` VALUES (1,0,0,0,0,NULL,NULL,'p1-g1-n01',NULL,'2026-10-14 07:20:19','2026-10-14 07:20:19'),(3,0,0,0,0,NULL,NULL,'p1-g1-n01',NULL,'2026-10-15 03:10:22','2026-10-15 03:10:22');
/*!40000 ALTER TABLE `user_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_word_progress`
--

DROP TABLE IF EXISTS `user_word_progress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_word_progress` (
  `user_id` bigint unsigned NOT NULL,
  `word_id` bigint unsigned NOT NULL,
  `mastery_level` tinyint unsigned NOT NULL DEFAULT '0',
  `mastery_score` tinyint unsigned NOT NULL DEFAULT '0',
  `last_reviewed_at` datetime DEFAULT NULL,
  `next_review_at` datetime DEFAULT NULL,
  `interval_days` decimal(6,2) NOT NULL DEFAULT '0.00',
  `ease_factor` decimal(4,2) NOT NULL DEFAULT '2.50',
  `last_answer_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_pronunciation_score` tinyint unsigned DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'new',
  `correct_streak` int NOT NULL DEFAULT '0',
  `correct_count` int NOT NULL DEFAULT '0',
  `wrong_count` int NOT NULL DEFAULT '0',
  `lapse_count` int NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`,`word_id`),
  KEY `fk_user_word_progress_word` (`word_id`),
  KEY `idx_user_word_progress_next` (`user_id`,`next_review_at`),
  KEY `idx_user_word_progress_status` (`user_id`,`status`),
  CONSTRAINT `fk_user_word_progress_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_user_word_progress_word` FOREIGN KEY (`word_id`) REFERENCES `vocabulary` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_word_progress`
--

LOCK TABLES `user_word_progress` WRITE;
/*!40000 ALTER TABLE `user_word_progress` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_word_progress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `role` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `avatar_url` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `google_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth_provider` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT 'local',
  `email_verified` tinyint(1) NOT NULL DEFAULT '0',
  `last_login_at` datetime DEFAULT NULL,
  `phone_verified` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `phone` (`phone`),
  UNIQUE KEY `google_id` (`google_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Call Preview','call-preview-local@example.test',NULL,'c13887e29b26d5a8ce5d89e2633a5f7b:8c3f7429019581a97a3118e59bf86ec33c7fb14eac04e5cf83e54bff3330b1d609c1de93cb44a334d1f812fd2a97582f0bf3469008e2c07496d26d3f0852ce6b',1,'2026-10-09 03:58:25','2026-10-14 10:38:56','admin',NULL,NULL,NULL,'local',0,'2026-10-14 17:38:56',0),(2,'LC Sim Student','lc-sim-student@example.invalid',NULL,'27fc9b684001ad56c21f6a72913a6e07:6746afe03cf6bdb6451086d7f97cc810d0100aa06885609dee88c1bd2789a3ed18737415d461b7312e0d70c91dfb5942c752df260fe38a5d35a7e6325ba86bfc',1,'2026-10-14 10:26:16','2026-10-16 07:52:23','user',NULL,NULL,NULL,'local',0,'2026-10-16 14:52:23',0),(3,'Staging Admin','xuanluong778@gmail.com',NULL,'524fe4f2cd1b00f93671773ce99d2876:ef4be91f0d0f807f2d0cbd441fea92606f9a59352d596b2b4a04a8e39fbcd2433fc1858aa52ebe879dccb8a25667d7afd696395bd876150dd53fb1ca9a1d8b3c',1,'2026-10-15 03:09:46','2026-10-16 07:52:22','admin',NULL,NULL,NULL,'local',0,'2026-10-16 14:52:22',0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vocabulary`
--

DROP TABLE IF EXISTS `vocabulary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vocabulary` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `word` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ipa` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vietnamese_meaning` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `part_of_speech` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `example_sentence` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vocab_source` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'beego',
  `basic_unit` int NOT NULL DEFAULT '0',
  `example_sentence_ipa` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `example_sentence_vi` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `semantic_hint` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_prompt` text COLLATE utf8mb4_unicode_ci,
  `image_style` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_source` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `audio_url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `example_audio_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `level` enum('beginner','elementary','intermediate') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'beginner',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_vocabulary_word_level_source_unit` (`word`,`level`,`vocab_source`,`basic_unit`),
  KEY `idx_vocabulary_level` (`level`),
  KEY `idx_vocabulary_word` (`word`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vocabulary`
--

LOCK TABLES `vocabulary` WRITE;
/*!40000 ALTER TABLE `vocabulary` DISABLE KEYS */;
/*!40000 ALTER TABLE `vocabulary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'beego_call_preview'
--

--
-- Dumping routines for database 'beego_call_preview'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-17 17:21:26
